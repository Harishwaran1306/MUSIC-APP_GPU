"""TamilTune API scaffold. Recognition/catalog providers are intentionally opt-in."""
from __future__ import annotations
import json, os, sqlite3, time
from pathlib import Path
from typing import Literal
from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv("TAMILTUNE_DB", str(ROOT / "tamiltune.sqlite3")))
MAX_AUDIO_BYTES = int(os.getenv("MAX_AUDIO_BYTES", str(20 * 1024 * 1024)))
ALLOWED_EXT = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".webm", ".mp4", ".mpeg"}

app = FastAPI(title="TamilTune API", version="0.2.0", description="Development API. Song recognition and catalog providers are not configured by default.")
origins = [x.strip() for x in os.getenv("TAMILTUNE_CORS_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"], allow_headers=["Content-Type", "Authorization"])


def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=5)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS settings (user_key TEXT PRIMARY KEY, interface_language TEXT NOT NULL DEFAULT 'en', song_language TEXT NOT NULL DEFAULT 'ta', speech_language TEXT NOT NULL DEFAULT 'ta');
        CREATE TABLE IF NOT EXISTS library (id INTEGER PRIMARY KEY AUTOINCREMENT, user_key TEXT NOT NULL, song_id TEXT NOT NULL, title TEXT NOT NULL, artist TEXT, added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_key,song_id));
        CREATE TABLE IF NOT EXISTS history (id INTEGER PRIMARY KEY AUTOINCREMENT, user_key TEXT NOT NULL, input_method TEXT NOT NULL, status TEXT NOT NULL, query_label TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        ''')

init_db()

class SettingsUpdate(BaseModel):
    interface_language: Literal["en", "ta"] = "en"
    song_language: str = Field(default="ta", max_length=20)
    speech_language: str = Field(default="ta-IN", max_length=20)

class LibraryItem(BaseModel):
    song_id: str = Field(min_length=1, max_length=200)
    title: str = Field(min_length=1, max_length=300)
    artist: str | None = Field(default=None, max_length=300)

class HistoryItem(BaseModel):
    input_method: Literal["recording", "humming", "whistle", "upload", "live"]
    status: Literal["matched", "no_match", "error", "not_configured"]
    query_label: str | None = Field(default=None, max_length=300)

@app.middleware("http")
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Cache-Control"] = "no-store" if request.url.path.startswith("/api/") else "no-cache"
    return response

@app.get("/api/health")
def health():
    return {"status": "ok", "api_version": app.version, "mode": "development", "recognition_configured": bool(os.getenv("TAMILTUNE_RECOGNITION_URL")), "catalog_configured": bool(os.getenv("TAMILTUNE_CATALOG_URL")), "lyrics_configured": bool(os.getenv("TAMILTUNE_LYRICS_URL"))}

@app.get("/api/categories")
def categories():
    names = ["New Releases", "Trending Songs", "Latest Tamil Songs", "Old Tamil Songs", "Golden Age Classics", "Evergreen Melodies", "Romantic Songs", "Melody Songs", "Folk Songs", "Devotional Songs", "Classical Music", "Dance Hits", "Sad and Emotional Songs", "Motivational Songs", "Instrumental Music", "Independent Artists", "Regional Music", "International Music"]
    return {"items": [{"id": str(i + 1), "name": n, "available": False} for i, n in enumerate(names)], "catalog_configured": bool(os.getenv("TAMILTUNE_CATALOG_URL")), "message": "Categories are available; song listings require a configured catalog."}

@app.get("/api/songs/search")
def search_songs(q: str = Query(default="", max_length=200), language: str | None = Query(default=None, max_length=20), page: int = Query(default=1, ge=1), limit: int = Query(default=20, ge=1, le=50)):
    endpoint = os.getenv("TAMILTUNE_CATALOG_URL")
    if not endpoint:
        return {"items": [], "query": q, "page": page, "limit": limit, "catalog_configured": False, "message": "Song catalog is not configured. No unverified matches were returned."}
    # Provider-specific request/auth/schema should be implemented for the chosen catalog.
    raise HTTPException(501, "Catalog endpoint is configured but its provider adapter is not implemented. Add the provider adapter before enabling search.")

@app.post("/api/recognition/identify")
async def identify_audio(file: UploadFile = File(...), input_method: Literal["recording", "humming", "whistle", "upload", "live"] = "upload", language: str = "ta-IN"):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_EXT and not (file.content_type or "").startswith("audio/"):
        raise HTTPException(415, "Unsupported audio file. Choose an MP3, WAV, M4A, AAC, OGG, FLAC, or WebM audio file.")
    data = await file.read(MAX_AUDIO_BYTES + 1)
    await file.close()
    if not data:
        raise HTTPException(400, "The uploaded audio file is empty.")
    if len(data) > MAX_AUDIO_BYTES:
        raise HTTPException(413, f"Audio exceeds the {MAX_AUDIO_BYTES // (1024*1024)} MB limit.")
    if not looks_like_audio(data, ext, file.content_type or ""):
        raise HTTPException(415, "The file does not appear to contain a supported audio format.")
    with connect() as c:
        c.execute("INSERT INTO history(user_key,input_method,status,query_label) VALUES(?,?,?,?)", ("guest", input_method, "not_configured", file.filename or "Audio upload"))
    endpoint = os.getenv("TAMILTUNE_RECOGNITION_URL")
    if not endpoint:
        return JSONResponse(status_code=503, content={"error": "recognition_not_configured", "message": "Audio was validated but not stored or sent to a recognition service. Configure TAMILTUNE_RECOGNITION_URL and implement its provider adapter to identify songs."})
    raise HTTPException(501, "Recognition endpoint is configured but its provider adapter is not implemented. No song match was claimed.")

def looks_like_audio(data: bytes, ext: str, content_type: str) -> bool:
    if data.startswith(b"RIFF") and data[8:12] == b"WAVE": return True
    if data.startswith(b"ID3") or data[:2] in (b"\xff\xfb", b"\xff\xf3", b"\xff\xf2"): return True
    if data.startswith(b"OggS"): return True
    if data.startswith(b"fLaC"): return True
    if data.startswith(b"\x1aE\xdf\xa3"): return True  # WebM/Matroska
    if len(data) > 12 and data[4:8] == b"ftyp": return True  # MP4/M4A container
    # MIME type alone is not sufficient proof of audio content.
    return False

@app.get("/api/settings")
def get_settings():
    with connect() as c:
        row = c.execute("SELECT * FROM settings WHERE user_key='guest'").fetchone()
        if not row:
            c.execute("INSERT INTO settings(user_key) VALUES('guest')")
            row = c.execute("SELECT * FROM settings WHERE user_key='guest'").fetchone()
    return {k: row[k] for k in ("interface_language", "song_language", "speech_language")}

@app.put("/api/settings")
def put_settings(body: SettingsUpdate):
    with connect() as c:
        c.execute("INSERT INTO settings(user_key,interface_language,song_language,speech_language) VALUES('guest',?,?,?) ON CONFLICT(user_key) DO UPDATE SET interface_language=excluded.interface_language,song_language=excluded.song_language,speech_language=excluded.speech_language", (body.interface_language, body.song_language, body.speech_language))
    return body.model_dump()

@app.get("/api/library")
def get_library():
    with connect() as c:
        rows = c.execute("SELECT id,song_id,title,artist,added_at FROM library WHERE user_key='guest' ORDER BY added_at DESC").fetchall()
    return {"items": [dict(r) for r in rows], "storage": "local-development-database", "authenticated": False}

@app.post("/api/library", status_code=201)
def add_library(body: LibraryItem):
    with connect() as c:
        try:
            cur = c.execute("INSERT INTO library(user_key,song_id,title,artist) VALUES('guest',?,?,?)", (body.song_id, body.title, body.artist))
        except sqlite3.IntegrityError:
            row = c.execute("SELECT id,song_id,title,artist,added_at FROM library WHERE user_key='guest' AND song_id=?", (body.song_id,)).fetchone()
            return dict(row)
        row = c.execute("SELECT id,song_id,title,artist,added_at FROM library WHERE id=?", (cur.lastrowid,)).fetchone()
    return dict(row)

@app.delete("/api/library/{song_id}")
def delete_library(song_id: str):
    with connect() as c:
        cur = c.execute("DELETE FROM library WHERE user_key='guest' AND song_id=?", (song_id,))
    if not cur.rowcount: raise HTTPException(404, "Saved song not found.")
    return {"deleted": True, "song_id": song_id}

@app.get("/api/history")
def get_history(limit: int = Query(default=50, ge=1, le=200)):
    with connect() as c:
        rows = c.execute("SELECT id,input_method,status,query_label,created_at FROM history WHERE user_key='guest' ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return {"items": [dict(r) for r in rows], "storage": "local-development-database", "authenticated": False}

@app.post("/api/history", status_code=201)
def add_history(body: HistoryItem):
    with connect() as c:
        cur = c.execute("INSERT INTO history(user_key,input_method,status,query_label) VALUES('guest',?,?,?)", (body.input_method, body.status, body.query_label))
    return {"id": cur.lastrowid, **body.model_dump()}

@app.delete("/api/history")
def clear_history():
    with connect() as c: c.execute("DELETE FROM history WHERE user_key='guest'")
    return {"cleared": True}

@app.get("/api/songs/{song_id}")
def song_detail(song_id: str):
    raise HTTPException(503, "Song detail is unavailable because no verified catalog is configured.")

@app.get("/api/songs/{song_id}/lyrics")
def song_lyrics(song_id: str):
    raise HTTPException(503, "Lyrics are unavailable because no licensed lyrics provider is configured.")

@app.get("/api/config")
def config():
    return {"mode": "development", "recognition_configured": bool(os.getenv("TAMILTUNE_RECOGNITION_URL")), "catalog_configured": bool(os.getenv("TAMILTUNE_CATALOG_URL")), "lyrics_configured": bool(os.getenv("TAMILTUNE_LYRICS_URL")), "max_audio_bytes": MAX_AUDIO_BYTES, "supported_interface_languages": ["en", "ta"]}
