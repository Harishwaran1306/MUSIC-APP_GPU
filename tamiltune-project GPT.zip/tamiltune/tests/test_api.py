import os, tempfile, unittest
from fastapi.testclient import TestClient
# Isolate the test database before importing the application.
tmp = tempfile.NamedTemporaryFile(suffix='.sqlite3', delete=False); tmp.close()
os.environ['TAMILTUNE_DB'] = tmp.name
from backend.app import app

class ApiTests(unittest.TestCase):
    def setUp(self): self.client = TestClient(app)
    def test_health_reports_dev_mode(self):
        r = self.client.get('/api/health'); self.assertEqual(r.status_code, 200); self.assertEqual(r.json()['mode'], 'development')
    def test_search_does_not_invent_results(self):
        r = self.client.get('/api/songs/search?q=Ilaiyaraaja'); self.assertEqual(r.status_code, 200); self.assertEqual(r.json()['items'], []); self.assertFalse(r.json()['catalog_configured'])
    def test_settings_persist(self):
        body = {'interface_language':'ta','song_language':'ta','speech_language':'ta-IN'}
        self.assertEqual(self.client.put('/api/settings', json=body).status_code, 200)
        self.assertEqual(self.client.get('/api/settings').json()['interface_language'], 'ta')
    def test_library_add_and_delete(self):
        r = self.client.post('/api/library', json={'song_id':'test-song','title':'Test song','artist':'Test artist'}); self.assertEqual(r.status_code, 201)
        self.assertEqual(self.client.get('/api/library').json()['items'][0]['title'], 'Test song')
        self.assertEqual(self.client.delete('/api/library/test-song').status_code, 200)
    def test_empty_audio_rejected(self):
        r = self.client.post('/api/recognition/identify', files={'file':('empty.wav', b'', 'audio/wav')}); self.assertEqual(r.status_code, 400)

if __name__ == '__main__': unittest.main()
